// pages/reser/reser.js
const util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  //选择时间事件
  datechange(event){
    //console.log(event.detail.value)
    this.setData({
      date:event.detail.value
    })
  },
  //表单重置事件
  formReset(){
    this.setData({
      date:''
    })
  },
//表单提交事件
  formSubmit(event){
    //console.log(event.detail.value)
     let ev = event.detail.value
    if(ev.phone&&ev.uname&&ev.sex&&ev.reserDate&&ev.time){
      //console.log('填写正确')
      const db = wx.cloud.database();
      db.collection('seat').doc(ev.reserDate)
        .field({
          [ev.time]:true
        }).get().then(res=>{
          //console.log(res.data)
          //得到包含键名的数组
          let arr = Object.keys(res.data[ev.time])
          //只能订5桌
          if(arr.length==5){
            wx.showToast({
              title:'已订满',
              icon:'error',
              duration:3000
            })
          }else if(arr.indexOf(ev.phone)>-1){
            //判断数组中是否包含某元素,未找到则返回 -1
            wx.showToast({
              title:'已订餐',
              icon:'error',
              duration:3000
            })
          }else{
            res.data[ev.time][ev.phone] = ev.uname+ev.sex;
            //写入数据表
            db.collection('seat').doc(ev.reserDate).update({
              data:{
                [ev.time]:res.data[ev.time]
              }
            }).then(res2=>{
              //查询user表是否有当前用户openid,如有执行更新，没有执行添加
              db.collection('user').where({
                _openid:wx.getStorageSync('openid')
              }).get().then(res3=>{
                //console.log(res3.data)
                let obj = res3.data[0]
                if(obj){
                  //_openid存在，直接写入数据
                  db.collection('user').doc(obj._id).update({
                    data: {
                      // 表示指示数据库将字段自增 10
                      info: db.command.unshift({
                        reserdate:ev.reserDate,
                        resertime:ev.time,
                        tablenum:arr.length+1
                      })
                    }
                  }).then(res4=>{
                    wx.showToast({
                      title:'订餐成功',
                      icon:'error',
                      duration:3000,
                      success:res6=>{
                        //执行跳转,关闭当前页面
                        wx.switchTab({
                          url: '../user/user'
                        })
                      }
                    })
                    
                  })


                }else{
                  //_openid不存在，先创建对应openid的一条数据
                  db.collection('user').add({
                    data:{
                      _openid:wx.getStorageSync('openid'),
                      info:[{
                        reserdate:ev.reserDate,
                        resertime:ev.time,
                        tablenum:arr.length+1
                      }]
                    }
                  }).then(res5=>{
                    wx.showToast({
                      title:'订餐成功',
                      icon:'error',
                      duration:3000,
                      success:res7=>{
                        //执行跳转,关闭当前页面
                        wx.switchTab({
                          url: '../user/user'
                        })
                      }
                    })
                  })
                }
              })
            })
          }
        })
    }else{
      wx.showToast({
        title:'信息填写不完整',
        icon:'error',
        duration:3000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //设置开始结束日期
    let startDate = util.formatTime(new Date());
    let endDate = util.formatDay(5);
    this.setData({
      start:startDate,
      end:endDate
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})