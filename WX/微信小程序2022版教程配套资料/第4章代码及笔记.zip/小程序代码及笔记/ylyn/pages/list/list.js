// pages/list/list.js
const app = getApp();
const url = app.globalData.url;
const util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  foodtap(event){    
    let id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `../content/content?id=${id}`
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    //console.log(options)
    //从服务器获取数据，条件classid
    let geturl = `${url}/db/list.php?where=classid=${options.classid}&start=0&num=10`
    util.getData2(geturl).then((res)=>{
      //console.log(res)
      let resArr=res;
      for(let i=0;i<resArr.length;i++){
        resArr[i].pic= url+ resArr[i].pic;
      }
      //数据绑定
      this.setData({
        food:resArr,
        classid:options.classid,
        num:resArr.length
      })

    })
    // wx.request({
    //   url: `${url}/db/list.php?where=classid=${options.classid}`,     
    //   success: (res)=>{
    //     //console.log(res.data)
    //     let resArr=res.data;
    //     for(let i=0;i<resArr.length;i++){
    //       resArr[i].pic= url+ resArr[i].pic;
    //     }
    //     //数据绑定
    //     this.setData({
    //       food:resArr
    //     })
    //   }
    // })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   * 在对应的json文件里配置启用下拉刷新:"enablePullDownRefresh": true
   */
  onPullDownRefresh: function () {
    //console.log('监听用户下拉动作');
    wx.showLoading({
      title: '正在刷新页面',
    })
    let geturl = `${url}/db/list.php?where=classid=${this.data.classid}&start=0&num=${this.data.num}`
    util.getData2(geturl).then((res)=>{
      //console.log(res)
      let resArr=res;
      for(let i=0;i<resArr.length;i++){
        resArr[i].pic= url+ resArr[i].pic;
      }
      //数据绑定
      this.setData({
        food:resArr
      })
      //隐藏loading提示框
      wx.hideLoading();
    });  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    //console.log("上拉触底")
    //上拉触底时在当前页面显示顶部标题栏加载动画
    wx.showNavigationBarLoading();
    let geturl = `${url}/db/list.php?where=classid=${this.data.classid}&start=${this.data.num}&num=10`
    util.getData2(geturl).then((res)=>{
      //判断空数组
      if(res.length==0){
        return false;
      }
      console.log(res);

      let resArr=res;
      for(let i=0;i<resArr.length;i++){
        resArr[i].pic= url+ resArr[i].pic;
      }
      //数据绑定
      this.setData({
        food: this.data.food.concat(resArr),
        num: this.data.num+resArr.length
      })
    })

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})