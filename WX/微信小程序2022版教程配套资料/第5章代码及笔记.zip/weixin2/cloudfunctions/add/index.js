// 云函数入口文件

//在云函数中操作数据库、存储以及调用其他云函数的微信提供的npm 包
const cloud = require('wx-server-sdk')

//在云函数中调用其他 API 前，同小程序端一样，也需要执行一次初始化
cloud.init()

// 云函数入口函数
//event参数是实际传参
//context 包含此处调用的调用信息和运行状态
exports.main = async (event, context) => {
  return event.x+event.y
}