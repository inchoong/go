【路径】
C:\Users\<用户名>\AppData\Local\Google\Chrome\User Data\Default\Extensions
C:\Users\<用户名>\AppData\Local\Microsoft\Edge\User Data\Default\Extensions

\ngpampappnmepgilojfohadhhmbhlaek

插件下载地址：https://chrome.google.com/webstore/detail/idm-integration-module/ngpampappnmepgilojfohadhhmbhlaek/related

<a href="https://chrome.google.com/webstore/detail/idm-integration-module/ngpampappnmepgilojfohadhhmbhlaek/related" 
title="【已打包】浏览器插件：IDM Integration Module | 一定要安装IDM的浏览器插件，才可以自动调用下载！">
浏览器插件：IDM Integration Module</a>
	 		 
-------------------------------------
IDM永久激活版注册码
提供IDM序列号使用，免费成为注册版本:

6KRUG-MPB4H-Z1KRG-F5MB1

LNOU7-WHRSY-02JUW-HRC1T

KYICP-AOYDJ-91VHT-L8ZVL

92854-7QHJY-7VR1G-F6LTP

OS5HG-K90NH-SXOGT-7JYEZ

R2C1T-O0KQO-JAVU2-4MMYP

M2A16-47AAW-6NLYP-V1E0J

IZO7M-360FW-QY1XP-AWLPN

46YFS-S9G7H-QZFWI-QQBQB

TUTR2-I2NHO-GQBC6-ZECWH

TUTR2-I2NHO-GQBC6-ZECWH
-------------------------------------