// pages/a/a.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isimg:true
  },
  //跳转
  navigateTo(){
    wx.navigateTo({
      url:'../b/b'
    })
  },

  //上传单个文件
  uploadImg(event){
    wx.chooseMessageFile({
      count:1,
      success:res=>{
        //console.log(res)
        //console.log(res.tempFiles[0].name)
        //console.log(res.tempFiles[0].path)
        wx.cloud.uploadFile({
          cloudPath:`images/${res.tempFiles[0].name}`,
          filePath:res.tempFiles[0].path
        }).then(res=>{
          //console.log(res)
          this.setData({
            fileID:res.fileID,
            isimg:false
          })
        })

      }
    })
  },
  //上传多个文件
  uploadImgS(event){
    wx.chooseMessageFile({
      count:9,
      success:res=>{
        wx.showLoading({
          title: '正在上传',
        })
        //console.log(res)
        //console.log(res.tempFiles[0].name)
        //console.log(res.tempFiles[0].path)
        let proArr = [];
        for(let i=0;i<res.tempFiles.length;i++){
          let pro = wx.cloud.uploadFile({
            cloudPath:`images/${res.tempFiles[i].name}`,
            filePath:res.tempFiles[i].path
          });
          proArr.push(pro);
        }
        //Promise.all可以将多个Promise实例包装成一个新的Promise实例
        Promise.all(proArr).then(res=>{
          //console.log(res)
          let imgArr=[];
          for(let j=0;j<res.length;j++){
            imgArr.push(res[j].fileID);
          }
          this.setData({
            imgurls:imgArr,
            isimg:false
          })
          wx.hideLoading()
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})