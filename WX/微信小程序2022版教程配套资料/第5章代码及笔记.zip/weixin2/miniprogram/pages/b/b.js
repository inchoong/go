// pages/b/b.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  //删除一张图片
  deleteImg(){
    wx.cloud.deleteFile({
      fileList: ['cloud://ylyn-6g23ncpa3a4fb69e.796c-ylyn-6g23ncpa3a4fb69e-1308441521/images/ggtd.jpg']//数组
    }).then(res=>{
      console.log(res)
    })
  },
  //下载一张图片
  downImg(){
    wx.cloud.downloadFile({
      fileID: 'cloud://ylyn-6g23ncpa3a4fb69e.796c-ylyn-6g23ncpa3a4fb69e-1308441521/images/ggdx.jpg',
      success:res=>{
        console.log(res.tempFilePath)// 返回临时文件路径
        wx.saveImageToPhotosAlbum({
          filePath:res.tempFilePath,
          success:res=>{
            console.log("保存成功")
          }
        })
      },
      fail:err=>{
        console.log(err)
      }
    })
  },

  //下载一个文件
  downFile(){
    wx.cloud.downloadFile({
      fileID: 'cloud://ylyn-6g23ncpa3a4fb69e.796c-ylyn-6g23ncpa3a4fb69e-1308441521/51zxw.doc',
      success:res=>{
        console.log(res.tempFilePath)// 返回临时文件路径
        wx.openDocument({
          filePath:res.tempFilePath,
          fileType:'doc',
          showMenu:true,
          success:res=>{
            console.log("保存成功")
          }
        })
      },
      fail:err=>{
        console.log(err)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})