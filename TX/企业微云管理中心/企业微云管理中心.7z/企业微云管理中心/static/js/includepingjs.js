if(window.location.protocol == 'https:')
{
	document.write('<script src="//pingjs.qq.com/tcss.ping.https.js" type="text/javascript" ></script>');
}
else
{
	document.write('<script src="//pingjs.qq.com/tcss.ping.js" type="text/javascript" ></script>');
}