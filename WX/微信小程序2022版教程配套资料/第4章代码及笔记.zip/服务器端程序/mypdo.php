<?php

//创建数据库操作类
class Mysqlpdo{
	private $pdo;
	//构造函数
	function __construct($info){
		$type = $info['type'];//数据库类型
		$host = $info['host'];//数据库地址
		$dbname = $info['dbname'];//数据库名
		$user = $info['user'];//数据库登陆名
		$pass = $info['pass'];//数据库密码
		//创建PDO基类实例化PDO对象，创建连接
		$this->pdo = new PDO($type.':host='.$host.';dbname='.$dbname,$user,$pass);
		//设置编码格式utf8,防止中文乱码
		$this->pdo->query("set names utf8");
	}
	
	//查询数据
	function pdo_query($sql,$x=true){
		//返回结果集对象
		$stmt = $this->pdo->query($sql);
		//设置查询模式（关联数组形式）
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		
		//返回条数
		if($x){
			$row=$stmt->fetch();//返回一条
			return $row;
		}else{
			$rows=$stmt->fetchAll();//返回多条
			return $rows;
		}
	}
	//查询数据
	
}

?>