-- phpMyAdmin SQL Dump
-- version 4.0.6-rc1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2022-01-04 22:53:11
-- 服务器版本: 5.5.62
-- PHP 版本: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `a0715180813`
--

-- --------------------------------------------------------

--
-- 表的结构 `parts`
--

CREATE TABLE IF NOT EXISTS `parts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `foodname` char(120) NOT NULL COMMENT '配菜名',
  `foodnum` char(120) NOT NULL COMMENT '数量',
  `foodunit` char(120) NOT NULL COMMENT '单位',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- 转存表中的数据 `parts`
--

INSERT INTO `parts` (`id`, `foodname`, `foodnum`, `foodunit`) VALUES
(1, '鲜排骨', '5/4/3', '市斤'),
(2, '兔肉', '5/4/3', '市斤'),
(3, '仔鸡', '5/4/3', '市斤'),
(4, '猪蹄', '5/4/3', '市斤'),
(5, '羊肉', '4/3/2', '市斤'),
(6, '肚条', '4/3/2', '市斤'),
(7, '鸭掌', '5/4/3', '市斤'),
(8, '大虾', '4/3/2', '市斤'),
(9, '大闸蟹', '4/3/2', '市斤'),
(10, '野生菌', '4/3/2', '市斤'),
(11, '土豆', '1', '份'),
(12, '黄瓜', '1', '份'),
(13, '洋葱', '1', '份'),
(14, '海带', '1', '份'),
(15, '藕片', '1', '份'),
(16, '蚕豆', '1', '份'),
(17, '萝卜', '1', '份'),
(18, '青菜', '1', '份'),
(19, '山药', '1', '份'),
(20, '木耳', '1', '份'),
(21, '鲜笋', '1', '份'),
(22, '白菜', '1', '份'),
(23, '豆干', '1', '份'),
(24, '芋头', '1', '份'),
(25, '火腿肠', '1', '份'),
(26, '鹅蛋菌', '1', '份'),
(27, '珍珠菌', '1', '份'),
(28, '姬菇菌', '1', '份'),
(29, '松树菌', '1', '份'),
(30, '羊肚菌', '1', '份'),
(31, '竹荪', '1', '份'),
(32, '香菇', '1', '份');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
