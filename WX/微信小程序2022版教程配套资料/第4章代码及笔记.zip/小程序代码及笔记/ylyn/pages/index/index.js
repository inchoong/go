const app = getApp();
const url = app.globalData.url;
const util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // gg:{pic:"/images/icon/guanguo.png",title:"干锅"}
    navbox:[
      {classid:"1",pic:"/images/icon/guanguo.png",title:"干锅"},
      {classid:"2",pic:"/images/icon/tangguo.png",title:"汤锅"}
    ]
  },

  foodtap(event){    
    let id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `../content/content?id=${id}`
    })
  },
  swipertap(event){    
    let id = event.target.dataset.id;
    wx.navigateTo({
      url: '../content/content?id='+id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    let menu = wx.getMenuButtonBoundingClientRect();
    //console.log(menu);
    //this.data.menutop=menu.top  错误
    this.setData({
      menutop:menu.top
    });
    let p = this.data.play;

    //从服务器获取数据,条件isgood>0
    //let that = this;
    let geturl=`${url}/db/list.php?where=isgood>0&start=0&num=7`;
    // app.getData1(geturl,(res)=>{
    //   console.log(res)
    // })
    util.getData2(geturl).then((res)=>{
      //console.log(res)
        let resArr=res;
        //对数据分组
        let swiper=[];
        let food=[];
        for(let i=0;i<resArr.length;i++){
          resArr[i].pic= url+ resArr[i].pic;
          if(resArr[i].isgood==1){
            swiper.push(resArr[i])
          }else{
            food.push(resArr[i])
          }
        }
        this.setData({
          swiper,
          food
        })
    })

    // wx.request({
    //   //url: 'http://192.168.1.222/db/list.php?where=isgood>0',
    //   url: `${url}/db/list.php`, 
    //   data: {
    //     where:"isgood>0"
    //   },
    //   success: (res)=> {
    //     //console.log(res.data)
    //     let resArr=res.data;
    //         //对数据分组
    //     let swiper=[];
    //     let food=[];
    //     for(let i=0;i<resArr.length;i++){
    //       resArr[i].pic= url+ resArr[i].pic;
    //       if(resArr[i].isgood==1){
    //         swiper.push(resArr[i])
    //       }else{
    //         food.push(resArr[i])
    //       }
    //     }
    //     this.setData({
    //       swiper,
    //       food
    //     })
    //   }
    // })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})