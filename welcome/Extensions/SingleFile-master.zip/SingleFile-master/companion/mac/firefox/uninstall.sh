#!/bin/sh
rm -f ~/Library/Application Support/Mozilla/NativeMessagingHosts/singlefile_companion.json