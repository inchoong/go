#!/bin/sh
rm -f ~/.mozilla/native-messaging-hosts/singlefile_companion.json