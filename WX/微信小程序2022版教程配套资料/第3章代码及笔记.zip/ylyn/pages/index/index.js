Page({

  /**
   * 页面的初始数据
   */
  data: {
    // gg:{pic:"/images/icon/guanguo.png",title:"干锅"}
    navbox:[
      {classid:"1",pic:"/images/icon/guanguo.png",title:"干锅"},
      {classid:"2",pic:"/images/icon/tangguo.png",title:"汤锅"}
    ]
  },

  foodtap(event){    
    let id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `../content/content?id=${id}`
    })
  },
  swipertap(event){    
    let id = event.target.dataset.id;
    wx.navigateTo({
      url: '../content/content?id='+id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let menu = wx.getMenuButtonBoundingClientRect();
    //console.log(menu);
    //this.data.menutop=menu.top  错误
    this.setData({
      menutop:menu.top
    });
    let p = this.data.play;

    //从服务器获取数据,条件isgood>0
    let resArr=[
      {
        "id": "1",
        "classid": "1",
        "isgood": "1",
        "title": "香辣排骨干锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/ggpg.jpg",
        "smalltext": "莲藕、土豆干香溢人，排骨脆香，红亮诱人。吃后还可加鲜汤同煮配菜，一锅两吃真是美哉！",
        "price": "大158/中128/小98元",
        "parts": "1,11,13,14,15,20,23"
      },
      {
        "id": "4",
        "classid": "1",
        "isgood": "2",
        "title": "卤味鸭掌干锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/ggyz.jpg",
        "smalltext": "鸭掌与很多做干锅的肉质不同，它的肉质很薄，干锅卤制更易入味。鸭脚、鸭翅、藕、土豆",
        "price": "大168/中148/小128元",
        "parts": "7,13,14,15,16,17,18"
      },
      {
        "id": "5",
        "classid": "1",
        "isgood": "2",
        "title": "美味大虾干锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/ggdx.jpg",
        "smalltext": "有虾,有土豆、莲藕,而且还可以搭配自己喜欢吃的菜,那味道实在是太好吃了。",
        "price": "大158/中128/小98元",
        "parts": "8,12,14,16,18,20,23"
      },
      {
        "id": "6",
        "classid": "1",
        "isgood": "1",
        "title": "香辣干锅蟹",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/ggx.jpg",
        "smalltext": "主要材料有螃蟹、莴笋、胡萝卜等，辅料有洋葱、红辣椒、大蒜、葱、姜、花椒、八角等，调料有牛肉豆豉酱、料酒、糖、生抽、盐、味精等。",
        "price": "大168/中148/小128元",
        "parts": "9,12,13,14,15,16,17"
      },
      {
        "id": "8",
        "classid": "2",
        "isgood": "2",
        "title": "砂仁肚条汤锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/tgdt.jpg",
        "smalltext": "行气止痛，化湿醒脾。脾调养药膳。适宜于食欲不振，胃及十二指肠溃疡等症。",
        "price": "大148/中118/小108元",
        "parts": "6,20,21,22,23,24,25"
      },
      {
        "id": "10",
        "classid": "2",
        "isgood": "2",
        "title": "鲜美羊肉汤锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/tgyr.jpg",
        "smalltext": "营养价值丰富，降糖降脂，美容养颜，增强抵抗力，做法多样，营养价值丰富,能缓解腰膝酸软。",
        "price": "大148/中128/小108元",
        "parts": "5,17,19,21,23,25,27"
      },
      {
        "id": "12",
        "classid": "2",
        "isgood": "1",
        "title": "保健野生菌汤锅",
        "pic": "http://www.ljgc.xyz/ylyn/images/food/tgysj.jpg",
        "smalltext": "鹅蛋菌、珍珠菌、姬菇菌、松树菌、羊肚菌、竹荪、野生香菇、榛蘑等，红枣、枸杞、姜、葱少许。",
        "price": "大168/中148/小128元",
        "parts": "25,26,27,28,29,30,31,32"
      }
    ]

    //对数据分组
    let swiper=[];
    let food=[];
    for(let i=0;i<resArr.length;i++){
      if(resArr[i].isgood==1){
        swiper.push(resArr[i])
      }else{
        food.push(resArr[i])
      }
    }
    // console.log(arr1)
    // console.log(arr2)
    this.setData({
      swiper,
      food
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})