#!/bin/sh
node ../../singlefile_companion.js