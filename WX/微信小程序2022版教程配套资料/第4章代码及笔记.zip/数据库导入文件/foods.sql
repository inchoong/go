-- phpMyAdmin SQL Dump
-- version 4.0.6-rc1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2022-01-04 22:52:57
-- 服务器版本: 5.5.62
-- PHP 版本: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `a0715180813`
--

-- --------------------------------------------------------

--
-- 表的结构 `foods`
--

CREATE TABLE IF NOT EXISTS `foods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` int(10) unsigned NOT NULL COMMENT '类型1:干锅,2:汤锅',
  `isgood` int(10) unsigned NOT NULL COMMENT '1:轮播，2:推荐',
  `title` char(120) NOT NULL COMMENT '标题',
  `pic` char(120) NOT NULL COMMENT '标题图片',
  `smalltext` char(255) NOT NULL COMMENT '简介',
  `price` char(120) NOT NULL COMMENT '单价',
  `parts` char(120) NOT NULL COMMENT '配菜id集合',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `foods`
--

INSERT INTO `foods` (`id`, `classid`, `isgood`, `title`, `pic`, `smalltext`, `price`, `parts`) VALUES
(1, 1, 1, '香辣排骨干锅', '/images/food/ggpg.jpg', '莲藕、土豆干香溢人，排骨脆香，红亮诱人。吃后还可加鲜汤同煮配菜，一锅两吃真是美哉！', '大158/中128/小98元', '1,11,13,14,15,20,23'),
(2, 1, 0, '麻辣兔丁干锅', '/images/food/ggtd.jpg', '肉香味美，色泽诱人，令人垂涎。主料：兔肉、笋子、藕、胡豆。辅料：姜、葱、蒜', '大148/中118/小88元', '2,11,12,13,14,15,16'),
(3, 1, 0, '益气干锅鸡', '/images/food/ggzj.jpg', '以鸡肉为主要食材，整道菜香脆酸辣俱全，颜色五彩缤纷，能促进食欲，营养价值丰富。', '大138/中118/小98元', '3,16,17,18,19,20,21'),
(4, 1, 2, '卤味鸭掌干锅', '/images/food/ggyz.jpg', '鸭掌与很多做干锅的肉质不同，它的肉质很薄，干锅卤制更易入味。鸭脚、鸭翅、藕、土豆', '大168/中148/小128元', '7,13,14,15,16,17,18'),
(5, 1, 2, '美味大虾干锅', '/images/food/ggdx.jpg', '有虾,有土豆、莲藕,而且还可以搭配自己喜欢吃的菜,那味道实在是太好吃了。', '大158/中128/小98元', '8,12,14,16,18,20,23'),
(6, 1, 1, '香辣干锅蟹', '/images/food/ggx.jpg', '主要材料有螃蟹、莴笋、胡萝卜等，辅料有洋葱、红辣椒、大蒜、葱、姜、花椒、八角等，调料有牛肉豆豉酱、料酒、糖、生抽、盐、味精等。', '大168/中148/小128元', '9,12,13,14,15,16,17'),
(7, 2, 0, '营养仔鸡汤锅', '/images/food/tgzj.jpg', '烹饪方法简单，营养丰富，一般人群均可食用，老人、病人、体弱者更宜食用。', '大138/中118/小98元', '3,19,20,21,22,23,24'),
(8, 2, 2, '砂仁肚条汤锅', '/images/food/tgdt.jpg', '行气止痛，化湿醒脾。脾调养药膳。适宜于食欲不振，胃及十二指肠溃疡等症。', '大148/中118/小108元', '6,20,21,22,23,24,25'),
(9, 2, 0, '水晶排骨汤锅', '/images/food/tgpg.jpg', '水晶排骨汤锅排骨营养丰富，味道鲜美。可根据自己的口味和需要配以不同的辅料，如：萝卜、白菜、冬瓜、椒盐等等。辅料不同，味道亦不同。', '大138/中118/小98元', '1,13,15,17,19,21,23'),
(10, 2, 2, '鲜美羊肉汤锅', '/images/food/tgyr.jpg', '营养价值丰富，降糖降脂，美容养颜，增强抵抗力，做法多样，营养价值丰富,能缓解腰膝酸软。', '大148/中128/小108元', '5,17,19,21,23,25,27'),
(11, 2, 0, '香糯蹄花汤花', '/images/food/tgth.jpg', '汤鲜味美，肉质香糯，泡菜味浓郁。主要材料猪蹄2只，泡萝卜、泡姜、泡青菜、大葱、盐、料酒、鲜汤、胡椒粉、味精、鸡精各适量。', '大138/中128/小118元', '4,15,16,18,20,22,24'),
(12, 2, 1, '保健野生菌汤锅', '/images/food/tgysj.jpg', '鹅蛋菌、珍珠菌、姬菇菌、松树菌、羊肚菌、竹荪、野生香菇、榛蘑等，红枣、枸杞、姜、葱少许。', '大168/中148/小128元', '25,26,27,28,29,30,31,32');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
