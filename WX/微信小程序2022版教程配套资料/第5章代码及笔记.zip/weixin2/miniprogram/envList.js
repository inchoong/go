const envList = [{"envId":"ylyn-6g23ncpa3a4fb69e","alias":"ylyn"}]
const isMac = false
module.exports = {
    envList,
    isMac
}