<?php
//数据库配置文件
$info = array(
	'type'=>'mysql',//数据库类型
	'host'=>'localhost',//数据库地址
	'dbname'=>'wx',//数据库名
	'user'=>'admin',//数据库登陆名
	'pass'=>'123456',//数据库密码
);

?>