<?php
	require('connect.php');  //引入数据库配置文件
	require('mypdo.php');  //引入数据库操作文件
	$pdo = new Mysqlpdo($info);//实例化数据库操作类
	
	$where = $_GET['where'];
	
	$row = getFood($where);
	
	$parts = getFoodList("FIND_IN_SET(id,'".$row['parts']."')");
//	
	$row['partsList']=$parts;
	
	echo json_encode($row,320);
	
	function getFood($data){
		global $pdo;
		$row = $pdo->pdo_query("select * from foods where ".$data);
		return $row;
	}
	
	
	function getFoodList($data){
		global $pdo;
		$row = $pdo->pdo_query("select * from parts where ".$data,false);
		return $row;
	}
	
	//关闭数据库连接
	$pdo = null;
	
?>