// pages/cs/cs.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   
  },
  outer(event){
    console.log("外层组件被触发了")
    console.log(event)
    // console.log(event.target.dataset.id)
    // console.log(event.target.dataset.title)
  },
  middle(){
    console.log("中层组件被触发了")
  },
  inner(){
    console.log("内层组件被触发了")
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})