window.feedbrobg = new feedbro.Background();
window.feedbrobg.initFeedbro();
