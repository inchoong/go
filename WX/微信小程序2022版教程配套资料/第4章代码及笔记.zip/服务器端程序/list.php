<?php
	require('connect.php');  //引入数据库配置文件
	require('mypdo.php');  //引入数据库操作文件
	$pdo = new Mysqlpdo($info);//实例化数据库操作类
	
	//$where = $_GET['where'];
	
	$rows = getFoodList($_GET);
	
//	JSON_UNESCAPED_UNICODE:不编码中文，正常输出中文(对应数字为256)
//	JSON_UNESCAPED_SLASHES:不转义反斜杠(对应数字为64)
//	256+64=320
	echo json_encode($rows,320);

	//判断是否有偏移量和数量
	function islimit($start,$num){
		if(empty($start)){
			$start=0;
		}
		if(empty($num)){
			$num=10;
		}
		return $start.",".$num;
	}
	
	
	function getFoodList($data){
		global $pdo;
		$limit = islimit($data['start'],$data['num']);
		$row = $pdo->pdo_query("select * from foods where ".$data['where']." limit ".$limit,false);
		return $row;
	}
	
	//关闭数据库连接
	$pdo = null;
	
?>