【路径】
C:\Users\<用户名>\AppData\Local\Google\Chrome\User Data\Default\Extensions
C:\Users\<用户名>\AppData\Local\Microsoft\Edge\User Data\Default\Extensions

\ngpampappnmepgilojfohadhhmbhlaek

插件下载地址：https://chrome.google.com/webstore/detail/idm-integration-module/ngpampappnmepgilojfohadhhmbhlaek/related

<a href="https://chrome.google.com/webstore/detail/idm-integration-module/ngpampappnmepgilojfohadhhmbhlaek/related" 
title="【已打包】浏览器插件：IDM Integration Module | 一定要安装IDM的浏览器插件，才可以自动调用下载！">
浏览器插件：IDM Integration Module</a>
	 		 
