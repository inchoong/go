// pages/content/content.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isplay:false
  },
  //暂停
  audioPause(){
    this.data.IAC.pause();
    this.setData({
      isplay:false
    })
  },
  //播放
  audioPlay(){
    this.data.IAC.play();
    this.setData({
      isplay:true
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options)
    //根据id到服务器查询相应数据，绑定到页面
    let food = {
      "id":"1",
      "pic":"http://www.ljgc.xyz/ylyn/images/food/ggpg.jpg",
      "title": "香辣排骨干锅",
      "price": "大158/中128/小98元",
      "smalltext": "莲藕、土豆干香溢人，排骨脆香，红亮诱人。吃后还可加鲜汤同煮配菜，一锅两吃真是美哉！",
      "partsList":[
        {
          "id": "1",
          "foodname": "鲜排骨",
          "foodnum": "5/4/3",
          "foodunit": "市斤"
        },
        {
          "id": "11",
          "foodname": "土豆",
          "foodnum": "1",
          "foodunit": "份"
        },
        {
          "id": "13",
          "foodname": "洋葱",
          "foodnum": "1",
          "foodunit": "份"
        },
        {
          "id": "14",
          "foodname": "海带",
          "foodnum": "1",
          "foodunit": "份"
        },
        {
          "id": "15",
          "foodname": "藕片",
          "foodnum": "1",
          "foodunit": "份"
        },
        {
          "id": "20",
          "foodname": "木耳",
          "foodnum": "1",
          "foodunit": "份"
        },
        {
          "id": "23",
          "foodname": "豆干",
          "foodnum": "1",
          "foodunit": "份"
        }
      ]
    }
    //动态设置导航栏标题
    wx.setNavigationBarTitle({
      title:food.title
    })

    this.setData({
      food,
      //创建音频
      "IAC":wx.createInnerAudioContext(),
      "IAC.src":"/images/music.mp3",
      "IAC.loop":true
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    //页面卸载时停止音乐
    this.data.IAC.pause();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})