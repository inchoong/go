// pages/c/c.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  //插入数据
  addData(){
    const db = wx.cloud.database();
    const foods = db.collection('foods');
    foods.add({
      data:{
        // _id:3,
        title:'香辣排骨干锅3',
        classid:1
      }
    }).then(res=>{
      console.log(res)
    })
  },
  //删除数据
  removeData(){
    const db = wx.cloud.database();
    // db.collection('foods').doc(1).remove().then(res=>{
    //   console.log(res)
    // })

    db.collection('foods').where({
      classid:1
    }).remove().then(res=>{
      console.log(res)
    })
  },
 // 局部更新数据
  upData(){
    const db = wx.cloud.database();
    db.collection('foods').doc(7).update({
      data:{
        classid:1,
        title:'营养老鸡汤锅'
      }
    }).then(res=>{
      console.log(res)
    })
  },
// 替换更新数据
  setData(){
    const db = wx.cloud.database();
    db.collection('foods').doc(7).set({
      data:{
        classid:2,
        title:'营养仔鸡汤锅'
      }
    }).then(res=>{
      console.log(res)
    })
  },
  //查询数据
  getData1(){
    const db = wx.cloud.database();
    db.collection('foods').doc(8).get().then(res=>{
      console.log(res.data)
    })
  },

  //查询一堆数据
  getData2(){
    const db = wx.cloud.database();
    // db.collection('foods').get().then(res=>{
    //   console.log(res.data)
    // })
    const cd = db.command
    // db.collection('foods').where({
    //   classid:1,
    //   isgood:cd.gt(0)
    // }).skip(1).limit(2).orderBy('isgood','desc').get().then(res=>{
    //   console.log(res.data)
    // })


    db.collection('foods').where({
      classid:1,
      isgood:cd.gt(0)
    }).orderBy('isgood','asc').get().then(res=>{
      console.log(res.data)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})