var feedbromenu = new feedbro.Mainmenu();

document.addEventListener('DOMContentLoaded', function () { 
	feedbromenu.customInit(); // gotcha: Chrome automatically calls function init() if it exists
});



