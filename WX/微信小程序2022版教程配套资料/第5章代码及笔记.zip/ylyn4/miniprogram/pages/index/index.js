const app = getApp();
const url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navbox: [{
        classid: "1",
        pic: "/images/icon/guanguo.png",
        title: "干锅"
      },
      {
        classid: "2",
        pic: "/images/icon/tangguo.png",
        title: "汤锅"
      }
    ]
  },

  foodtap(event) {
    let id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `../content/content?id=${id}`
    })
  },
  swipertap(event) {
    let id = event.target.dataset.id;
    wx.navigateTo({
      url: '../content/content?id=' + id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    let menu = wx.getMenuButtonBoundingClientRect();

    this.setData({
      menutop: menu.top
    });
    let p = this.data.play;

    //获取数据,条件isgood>0
    const db = wx.cloud.database();
    db.collection('foods').field({
      isgood: true,
      pic: true,
      price: true,
      title: true,
      smalltext: true,
    }).where({
      isgood: db.command.gt(0)
    }).get().then(res => {
      //console.log(res)
      let resArr = res.data;
      //对数据分组
      let swiper = [];
      let food = [];
      for (let i = 0; i < resArr.length; i++) {
        resArr[i].pic = url + resArr[i].pic;
        if (resArr[i].isgood == 1) {
          swiper.push(resArr[i])
        } else {
          food.push(resArr[i])
        }
      }
      this.setData({
        swiper,
        food
      })
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})